import streamlit as st

st.set_page_config(
    page_title="Binary Number System Converter",
    page_icon="🔢",
    layout="centered",
)

st.title("🔢 Binary Number System Converter")
st.subheader("Digital Electronics | ECE")
st.write(
    "Convert binary numbers to decimal and decimal numbers "
    "to binary using this interactive learning tool."
)

mode = st.selectbox(
    "Choose a conversion",
    ["Binary to Decimal", "Decimal to Binary"],
)

number = st.text_input(
    "Enter your number",
    placeholder="Example: 1010",
)

if st.button("Convert", type="primary"):
    number = number.strip()

    if not number:
        st.warning("Please enter a number.")

    elif mode == "Binary to Decimal":
        if all(digit in "01" for digit in number):
            result = int(number, 2)
            st.success(f"Decimal result: {result}")

            st.write("**Working:**")
            terms = [
                f"{digit} × 2^{power}"
                for power, digit in enumerate(reversed(number))
            ]
            st.code(" + ".join(reversed(terms)))
            st.write(f"Therefore, {number}₂ = {result}₁₀")
        else:
            st.error("Invalid binary number. Use only 0 and 1.")

    else:
        if number.isascii() and number.isdecimal():
            result = bin(int(number))[2:]
            st.success(f"Binary result: {result}")
            st.write(f"Therefore, {number}₁₀ = {result}₂")
        else:
            st.error(
                "Enter a non-negative whole number using digits 0–9."
            )

st.divider()
st.markdown("### Practice examples")
st.write("• Binary 1010 = Decimal 10")
st.write("• Binary 1111 = Decimal 15")
st.write("• Decimal 25 = Binary 11001")

st.caption("Student Project | Digital Electronics | ECE")
