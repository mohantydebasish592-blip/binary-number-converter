# Binary Number System Converter

A simple Digital Electronics project built with Python and Streamlit.

## Features
- Binary to decimal conversion
- Decimal to binary conversion
- Input validation
- Step-by-step binary place-value working
- Practice examples

## Run locally
Install Python, then run:

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy for a public link
1. Upload `app.py` and `requirements.txt` to a GitHub repository.
2. Open https://share.streamlit.io/
3. Sign in with GitHub and create a new app.
4. Select your repository, branch `main`, and main file `app.py`.
5. Deploy. Streamlit will provide a public `*.streamlit.app` URL.

Note: This package contains the app files, not a deployed public URL.
